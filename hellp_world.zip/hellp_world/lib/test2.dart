import 'dart:convert' as Converter;
import 'package:http/http.dart' as http;
import 'package:intl/intl.dart';

main(List<String> args) {
  // var json = '[{"id": "1", "name": "mohamed"},{"id": "2","name": "booz"}]';
  // var parsedData = Converter.jsonDecode(json);
  // print(parsedData.runtimeType);
  // print(parsedData[0]);
  // for (var p in parsedData) {
  //   print(p);
  // }

  // (parsedData as List).forEach((v) {
  //   print(v);
  // });
  // print(Converter.jsonEncode(parsedData));
  // dynamic parsedData;
  // String url = "http://openweathermap.org/data/2.5/forecast?q=" +
  //     "azemmour" +
  //     "&appid=b6907d289e10d714a6e88b30761fae22";
  // http.get(Uri.encodeFull(url), headers: {'accept': 'application/json'}).then(
  //     (response) {
  //   parsedData = Converter.jsonDecode(response.body)['list'];
  //   // print(parsedData);
  //   print(parsedData[0]['weather'][0]['icon']);
  // }).catchError((err) {
  //   print(err);
  // });
  // var now = new DateTime.now().millisecondsSinceEpoch;

  // print(now);
  // // print(parsedData);
  // print(DateTime(now).toIso8601String());
  // var format = DateFormat("HH:mm a E d/M/y");
  // var str = format.format(DateTime.now());
  // print(str);
  String query = "marrakech";
  String url =
      "https://pixabay.com/api/?key=15799459-72fb38ad7afed098b3f7e2db7&q=" +
          query +
          "&image_type=photo";
  http.get(Uri.encodeFull(url), headers: {'accept': 'application/json'}).then(
      (response) {
//          print(response.body);
    dynamic r = Converter.jsonDecode(response.body);
    print(r['total']);
    
    // print(r.toString());
    print(r);
    // print(widget.total.toString());
//        print(widget.data.toString());
//        print("boo" + url);
  }).catchError((err) {
    print(err);
  });
}
