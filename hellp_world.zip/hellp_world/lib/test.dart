// import 'dart:convert' as boo;

// class Person {
//   int id;
//   String name;
//   Person({this.id = 2, this.name = 'boi'});
//   // we can use ONLY one constructor
//   @override
//   String toString() {
//     return id.toString() + ',' + name.toString();
//     ;
//   }
// }

// main(List<String> args) {
//   //Person a = Person(name: 'name');
//   //print('name ->${a.name} \nid -> ${a.id}' + 'concatenation' + a.id.toString());
//   List<Person> persons = new List();
//   persons.add(new Person(id: 1, name: "dikead"));
//   persons.add(new Person(id: 2, name: "Mohammed"));
//   // for (Person p in persons) {
//   //   print(p.toString());
//   // }

//   // persons.forEach((v) {
//   //   print(v);
//   // });
//   //variables
//   var persons2 = [
//     Person(id: 1, name: 'boo'),
//     Person(id: 2, name: 'aaa'),
//     Person(id: 3, name: 'zzz'),
//   ];
//   // persons2.forEach((p) {
//   //   print(p.toString());
//   // });
//   Map<String, dynamic> data =
//       new Map(); //better than object, you can use attributes without having to cast,useful if your data is dynamic
//   data['p1'] = Person(id: 1, name: 'Mohammed');
//   data['p2'] = Person(id: 2, name: 'aaaaaaaaa');
//   data.forEach((key, value) {
//     print('key:' + key + '   value:${value}' + data[key].name.toString());
//     //or data[ key]
//     //CASTING
//     //CASTING
//     //CASTING
//     Object a = Person(id: 1, name: 'boo');
//     print((a as Person).name);
//   });
//   //what
//   var array = [
//     {
//       'title': 'Q1',
//       'answers': [
//         {'answer': 'Answer 11', 'correct': false},
//         {'answer': 'Answer 12', 'correct': true},
//         {'answer': 'Answer 13', 'correct': false},
//       ]
//     },
//     {
//       'title': 'Q2',
//       'answers': [
//         {'answer': 'Answer 15', 'correct': false},
//         {'answer': 'Answer 16', 'correct': true},
//         {'answer': 'Answer 17', 'correct': false},
//       ]
//     },
//   ];
// //
//   print('array type -> ' + array.runtimeType.toString());
//   array.forEach((v) {
//     print('title->' + v['title']);

//     print('typeof answers' + v['answers']);
//     (v['answers'] as List).forEach((answer) {
//       print('Answer' + answer['answer'] + ',' + answer['correct'].toString());

//   });
//   //JSON
//   var json = '[{"id": "1", "name": "mohamed"},{"id": "2","name": "booz"}]';
//   var parsedData = boo.jsonDecode(json);
//   print(parsedData.runtimeType);
// }
