import 'dart:io';
import 'package:flutter/material.dart';
import 'package:hellp_world/main-drawer.dart';
class Camera extends StatefulWidget {
  @override
  _CameraState createState() => _CameraState();
}

class _CameraState extends State<Camera> {
  String scannedText;
  File imageFile;

  @override
  Widget build(BuildContext context) {
    return
      Scaffold(
        drawer: MainDrawer(),
          appBar: AppBar(
            title: Text("Camera",style: TextStyle(backgroundColor: Colors.red),),

          ),
         body: Column(
           children: <Widget>[
             MaterialButton(
               child: Text("Pick image",style: TextStyle(color: Colors.white),),
               onPressed: (){
                 print("pick Image btn pressed");
               },
             ),
             Container(
               width: double.infinity,
               height: 200,
               padding: const EdgeInsets.all(8),
               child: SingleChildScrollView(
                 child: Text("${scannedText == null ? "":scannedText}"),
               ),
             ),
             imageFile == null ? Text("Pas dimage"
             ):Image.file(imageFile,height: 300,)
           ],
         ),
      );
  }

}