class myException {
  a() {
    print('hahaha lmao');
  }

  @override
  String toString() {
    return 'MYEXCEPTION';
  }
}

abstract class IService {
  double add(double a, double b);
  double sub(double a, double b);
  double produit(double a, double b) {
    return a * b;
  }

  double div(double a, double b) {
    if (b == 0) throw myException;
    return a / b;
  }
}

class ServiceImpl extends IService {
  @override
  double add(double a, double b) {
    // TODO: implement add
    return a + b;
  }

  @override
  double sub(double a, double b) {
    // TODO: implement sub
    return a - b;
  }
}

void main(List<String> args) {
  IService a = new ServiceImpl();
  print(a.add(1, 2));
  try {
    print(a.div(1, 0));
  } catch (e) {
    print(e.toString());
  }
}
